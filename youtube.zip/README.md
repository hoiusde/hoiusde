﻿# Have Fun With Python [#No.1]
## Cày View Youtube

Sử dụng python và Selenium để tạo ra một sript tự động mở browser và view một list các video được chỉ định sẵn.
Kiến thức:
- Biết cách đọc/ghi file
- Biết cách cài đặt một thư viện
- Biết cách sử dụng thư viện Selenium cơ bản
- Các câu lệnh cơ bản trong Python

Video hướng dẫn chi tiết: https://www.youtube.com/watch?v=XSQT9RBKoCs

Bài viết hướng dẫn chi tiết: http://www.hoangvancong.com/2020/07/02/web-automation-with-selenium-python/

* FireFox Driver:
geckodriver: https://github.com/mozilla/geckodriver/releases

* Chrome Driver:
http://chromedriver.storage.googleapis.com/index.html


Add Driver to you PATH.
With MAC, copy driver to /usr/local/bin folder
